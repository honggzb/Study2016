import {NgModule, Component, Injectable} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {JsonpModule, Jsonp, Response} from '@angular/http';     //1) import
import {ReactiveFormsModule, FormControl, FormsModule} from '@angular/forms';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/do';

class SearchItem {
  constructor(public name: string,
              public artist: string,
              public link: string,
              public thumbnail: string,
              public artistId: string) {
  }
}

@Injectable()
export class SearchService {
  apiRoot: string = 'https://itunes.apple.com/search';
  
  constructor(private jsonp:Jsonp){}     //4) change type
  
  search(term:string): Observable<SearchItem[]> {     
    let apiURL = `${this.apiRoot}?term=${term}&media=music&limit=20&callback=JSONP_CALLBACK`;  //3)callback=JSONP_CALLBACK
    return this.jsonp.request(apiURL)                            //5) this.jsonp.request
                    .map(res => {
                      return res.json().results.map(item => {
                        return new SearchItem(
                          item.trackName,
                          item.artistName,
                          item.trackViewUrl,
                          item.artworkUrl30,
                          item.artistId
                        );
                      });
                    });
  }
}

@Component({
  selector: 'app',
  template: ` 
  <form class="form-inline">
  	<div class="form-group">
  		<input type="search"
  		       class="form-control"
  		       placeholder="Enter search string"
  		       [formControl]="searchField">
  	</div>
  </form>
  
  <hr/>
  
  <div class="text-center">
    <p class="lead" *ngIf="loading">Loading...</p>
  </div>
  
  <ul class="list-group">
  	<li class="list-group-item"
  	    *ngFor="let track of results | async">  
  		<img src="{{track.thumbnail}}">
  		<a target="_blank"
  		   href="{{track.link}}">{{ track.name }}
  		</a>
  	</li>
  </ul>
 `
})
class AppComponent {
  private loading: boolean = false;
  private results: Observable<SearchItem[]>;  
  private searchField: FormControl;   
  
  constructor(private itunes: SearchService) {}
  
  ngOnInit(){
    this.searchField = new FormControl();
    this.results = this.searchField.valueChanges
                .debounceTime(400)                    
                .distinctUntilChanged()
                .do(() => this.loading=true)        
                .switchMap(term => this.itunes.search(term))   
                .do(() => this.loading=false)
  }
  
  doSearch(term: string){
    this.itunes.search(term);
  }
}

@NgModule({
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    JsonpModule    //2) import in NgModule
  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  providers: [SearchService]
})
export class AppModule {
}

platformBrowserDynamic().bootstrapModule(AppModule);