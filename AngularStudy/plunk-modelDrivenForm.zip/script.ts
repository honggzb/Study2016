import {
    NgModule,
    Component,
    Pipe,
    OnInit
} from '@angular/core';
import {
    ReactiveFormsModule,
    FormsModule,
    FormGroup,
    FormControl,
    Validators,
    FormBuilder
} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

@Component({
  selector: 'model-form',
  template: `
  <form novalidate [formGroup]="myform">
    <fieldset formGroupName="name" [ngClass]="{
        'has-danger': myform.controls.name.controls.firstName.invalid && myform
        .controls.name.controls.firstName.dirty,
        'has-success': myform.controls.name.controls.firstName.valid && myform
        .controls.name.controls.firstName.dirty}"> 
      <div class="form-group">
        <label>First Name</label>
        <input type="text" class="form-control" formControlName="firstName">
      </div>
      <div class="form-group">
        <label>Last Name</label>
        <input type="text" class="form-control" formControlName="lastName">
      </div>
    </fieldset>
    <div class="form-group" [ngClass]="{
        'has-danger': myform.controls.email.invalid && myform.controls.email.dirty,
        'has-success': myform.controls.email.valid && myform.controls.email.dirty}">
      <label>Email</label>
      <input type="email" class="form-control" formControlName="email">
    </div>
    <div class="form-group">
      <label>Password</label>
      <input type="password" class="form-control" formControlName="password">
    </div>
    <div class="form-control-feedback" 
    *ngIf="myform.controls.password.errors && (myform.controls.password.dirty || myform.controls.password.touched)">
      <p *ngIf="myform.controls.password.errors.required">Password is required</p>
      <p *ngIf="myform.controls.password.errors.minlength">Password must be 8 characters long, we need
      another {{password.errors.minlength.requiredLength -
      password.errors.minlength.actualLength}} characters </p>
    </div>
    <div class="form-group">
      <label>Language</label>
      <select class="form-control" formControlName="language">
        <option value="">Please select a language</option>
        <option *ngFor="let lang of langs" [value]="lang">{{lang}}</option>
      </select>
    </div>
    <pre>{{myform.value | json}}</pre>
    <pre>Dirty ? {{myform.controls.email.dirty}}</pre>
    <pre>Pristine ? {{myform.controls.email.pristine}}</pre> <!-- true when only the use enter some letter -->
    <pre>Touched? {{ myform.controls.email.touched }}</pre>
    <pre>Untouched? {{ myform.controls.email.untouched }}</pre>
    <pre>Valid? {{ myform.controls.email.valid }}</pre>
    <pre>Invalid? {{ myform.controls.email.invalid }}</pre>
  </form>
  `
})
class ModelFormComponent implements OnInit  {
  langs: string[] = [
            'English',
            'French',
            'German',
            ];
  myform: FormGroup;
  
  ngOnInit() {
    this.myform = new FormGroup({
      name: new FormGroup({
        firstName: new FormControl('', Validators.required),
        lastName: new FormControl('', Validators.required),
      }),
      email: new FormControl('',[
        Validators.required,
        Validators.pattern("[^ @]*@[^ @]*")
        ]),
      password: new FormControl('',[
        Validators.required,
        Validators.minLength(8)
        ]),
      language: new FormControl()
    });
  }
}

@Component({
  selector: 'app',
  template: `<model-form></model-form>`
})
class AppComponent {
}

@NgModule({
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  declarations: [
    AppComponent,
    ModelFormComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

platformBrowserDynamic().bootstrapModule(AppModule);