import { Component, NgModule, Input, Output, EventEmitter } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

class Joke {  //domain model
  setup: string;
  punchline: string;
  hide: boolean;
  
  constructor(setup:string, punchline:string) {
    this.setup = setup;
    this.punchline = punchline;
    this.hide = true;
  }
  
  toggle(){
    this.hide = !this.hide;
  }
}

//let joke = new Joke("What did  the cheese say when it looked in the mirror?","Halloumi (hello me)");

@Component({
  selector: 'joke',
  template: `<div class="panel panel-info">
               <div class="panel-heading">{{ joke.setup }}</div>
               <div class="panel-body">
                  <p class="card-text" [hidden]="joke.hide">{{ joke.punchline }}</p>
                  <button class="btn btn-primary" (click)="joke.toggle()">Tell Me</button>
                  <button class="btn btn-danger" (click)="deleteJoke()">Delete</button>
               </div>
             </div>`
})
class JokeComponent {
  @Input() joke: Joke;
  @Output() jokeDeleted = new EventEmitter<Joke>();
  
  deleteJoke(){
    this.jokeDeleted.emit(this.joke);
  }
}


@Component({
  selector: 'joke-list',
  template: `
    <joke-form (jokeCreated)="addJoke($event)"></joke-form>
    <joke *ngFor="let j of jokes" [joke]="j" (jokeDeleted)="deleteJoke($event)"></joke>`
})
class JokeListComponent {
  jokes: Joke[];
  
  constructor(){
    this.jokes = [
      new Joke("What did  the cheese say when it looked in the mirror?","Halloumi (hello me)"),
      new Joke("What kind of cheese do you use to disguise a small horse?","Mask-a-pony (Mascarpone)"),
      new Joke("A kid threw a lump of cheddar at me","I thought 'That's not very mature.")
    ];
  }
  addJoke(joke){
    this.jokes.unshift(joke);
  }
  deleteJoke(joke){
    let indexToDelete = this.jokes.indexOf(joke);
    if(indexToDelete !== -1){
      this.jokes.splice(indexToDelete, 1);
    }
  }
}

@Component({
  selector: 'joke-form',
  template: `<div class="panel panel-info">
               <div class="panel-heading">Create Joke</div>
               <div class="panel-body">
                  <div class="form-group"><input type="text" class="form-control" 
                  placeholder="Enter the setup" #setup></div>
                  <div class="form-group"><input type="text" class="form-control" 
                  placeholder="Enter the punchline" #punchline></div>
                  <button class="btn btn-primary" (click)="createJoke(setup.value, punchline.value)">Create</button>
               </div>
             </div>`
})
class JokeFormComponent {
  @Output() jokeCreated = new EventEmitter<Joke>();
  
  createJoke(setup: string, punchline: string){
    this.jokeCreated.emit(new Joke(setup,punchline));
  }
}

@Component({    
  selector: 'app',
  template: `<joke-list></joke-list>`
})
class AppComponent {
}

@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent, JokeComponent, JokeListComponent, JokeFormComponent],
  bootstrap: [AppComponent]
})
export class AppModule {   //root module
}

platformBrowserDynamic().bootstrapModule(AppModule);