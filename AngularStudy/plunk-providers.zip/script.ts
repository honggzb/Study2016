import {NgModule, Component, Injectable} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

class SimpleService{
  value: string;
}

@Component({
  selector: 'child',
  template: `<div class="child">
                <p>Child</p>
                {{ service.value }}
              </div>`,
  styles: [`
            .child {
              background-color: #239CDE;
              padding: 10px;
            }
          `],
})
class ChildComponent {
  constructor(private service: SimpleService) { }
}

@Component({
  selector: 'parent',
  template: `<div class="parent">
                <p>Parent</p>
                <form novalidate>
                  <div class="form-group">
                    <input type="text" class="form-control" name="value" 
                    [(ngModel)]="service.value">
                  </div>
                </form>
                <!-- <child></child>  -->
                <ng-content></ng-content>  <!-- 3) viewProviders on components  -->
              </div>`,
  styles: [`
            .parent {
              background-color: #D1E751;
              padding: 10px;
            }
          `],
  //providers: [SimpleService]   //2) Component.providers
  viewProviders: [SimpleService]   //2) Component.providers
})
class ParentComponent {
  constructor(private service: SimpleService) { }
}

@Component({
  selector: 'app',
  template: `<div class="row">
                <div class="col-xs-6">
                  <!-- <parent></parent>  -->
                  <parent><child></child></parent>  <!-- 3) viewProviders on components  -->
                </div>
                <div class="col-xs-6">
                  <!-- <parent></parent>  -->
                  <parent><child></child></parent>  <!-- 3) viewProviders on components  -->
                </div>
            </div>`
})
class AppComponent {
}

@NgModule({
  imports: [BrowserModule, FormsModule],
  declarations: [AppComponent, ChildComponent, ParentComponent],
  bootstrap: [AppComponent],
  providers: [SimpleService]   //1) ngModule providers
})
class AppModule {
}

platformBrowserDynamic().bootstrapModule(AppModule);
