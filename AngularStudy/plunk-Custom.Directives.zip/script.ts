import { 
  Component,
  Directive,
  Renderer,
  ElementRef,
  NgModule,
  Input,
  Output,
  EventEmitter,
  HostListener,
  HostBinding
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

class Joke {  //domain model
  setup: string;
  punchline: string;
  hide: boolean;
  
  constructor(setup:string, punchline:string) {
    this.setup = setup;
    this.punchline = punchline;
    this.hide = true;
  }
  
  toggle(){
    this.hide = !this.hide;
  }
}

/*
input {
  ...
}
*/
@Directive({
  selector: '[ccCardHover]'
})
class CardHoverDirective {
  @HostBinding('class.card-outline-primary') private ishovering: boolean;
  @Input('ccCardHover') config: Object = {
    querySelector: '.card-text'
  }
  constructor(private el: ElementRef, private renderer: Renderer){
    renderer.setElementStyle(el.nativeElement, 'backgroundColor', 'gray');
  }
  @HostListener('mouseover') onMouseOver(){
    //window.alert("hover");
    let part = this.el.nativeElement.querySelector('.card-text');
    this.renderer.setElementStyle(part, 'display','block');
    this.ishovering = true;
  }
  @HostListener('mouseout') onMouseOut(){
    let part = this.el.nativeElement.querySelector(this.config.querySelector);
    this.renderer.setElementStyle(part, 'display','none');
    this.ishovering = false;
  }
}

@Component({
  selector: 'joke',
  template: `<div class="card card-block" [ccCardHover]="{querySelector:'p'}">
              <h4 class="card-title">{{data.setup}}</h4>
              <p class="card-text" [hidden]="data.hide">{{data.punchline}}</p>
              <button (click)="data.toggle()" class="btn btn-primary">Tell Me</button>
            </div>`
})
class JokeComponent {
  @Input('joke') data: Joke;
}


@Component({
  selector: 'joke-list',
  template: `
    <joke *ngFor="let j of jokes" [joke]="j"></joke>`
})
class JokeListComponent {
  jokes: Joke[];
  
  constructor(){
    this.jokes = [
      new Joke("What did  the cheese say when it looked in the mirror?","Halloumi (hello me)"),
      new Joke("What kind of cheese do you use to disguise a small horse?","Mask-a-pony (Mascarpone)"),
      new Joke("A kid threw a lump of cheddar at me","I thought 'That's not very mature.")
    ];
  }
}

@Component({
  selector: 'app',
  template: `<joke-list></joke-list>`
})
class AppComponent {
}

@NgModule({
  imports: [BrowserModule],
  declarations: [AppComponent, JokeComponent, JokeListComponent, CardHoverDirective],
  bootstrap: [AppComponent]
})
export class AppModule {
}

platformBrowserDynamic().bootstrapModule(AppModule);