import {LoginComponent} from './login.component';
import {AuthService} from "./auth.service";

class MockedAuthService extends AuthService {
  authenticated = false;
  
  isAuthenticated() {
    return this.authenticated;
  }
}


describe('Component: Login', () => {
  let component: LoginComponent;
  //let service: AuthService;
  let service: MockedAuthService;
  
  beforeEach(() => {
    //service = new AuthService();
    service = new MockedAuthService();
    component = new LoginComponent(service);
  });
  
  afterEach(() => {
    //localStorage.removeItem('token');
    service = null;
    component = null;
  });
  
  it('canLogin returns false when the user is not authenticated', () => {
    service.authenticated = false;
    expect(component.needsLogin()).toBeTruthy();
  });
  
  it('needsLogin returns false when the user is not authenticated', () => {
    //localStorage.setItem('token', '1234');
    service.authenticated = true;
    expect(component.needsLogin()).toBeFalsy();
  });
});