// export class AuthService {
//   isAuthenticated(): boolean {
//     return !!localStorage.getItem('token');
//   }
// }

export class AuthService {
  isAuthenticated(): boolean {
    return Promise.resolve(!!localStorage.getItem('token'));  // return a Promise for asyn test
  }
}