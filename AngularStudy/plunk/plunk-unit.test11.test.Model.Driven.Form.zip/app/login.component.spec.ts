
import {TestBed, ComponentFixture} from '@angular/core/testing';
import {ReactiveFormsModule, FormsModule} from "@angular/forms";
import {LoginComponent, User} from "./login.component";

describe('Component: Login', () => {
  
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  
  beforeEach(() => {
    // refine the test module by declaring the test component
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [LoginComponent]
    });
    
    // create component and test fixture
    fixture = TestBed.createComponent(LoginComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    // UserService provided to the TestBed
    component.ngOnInit();   //manually trigger the ngOnInit lifecycle function, Angular won’t cal
  });
  
  //Testing form validity
  it('form invalid when empty', () => {
   expect(component.form.valid).toBeFalsy();
  });
  
  //Testing form field validity and error
  it('email field validity', () => {
    let errors = {};
    let email = component.form.controls['email'];   // test validity
    
    errors = email.errors || {};
    expect(errors['required']).toBeTruthy();    //test error
    
    // email.setValue("test");
    // errors = email.errors || {};
    // expect(errors['pattern']).toBeTruthy();  //test error
  });
  
  //test submit
  it('submitting a form emits a user', () => {
    expect(component.form.valid).toBeFalsy();
    component.form.controls['email'].setValue("test@test.com");
    component.form.controls['password'].setValue("123456789");
    expect(component.form.valid).toBeTruthy();
    
    let user: User;
    component.loggedIn.subscribe((value) => user=value);
    component.login();  //trigger the login function
    
    expect(user.email).toBe("test@test.com");
    expect(user.password).toBe("123456789");
  });

})