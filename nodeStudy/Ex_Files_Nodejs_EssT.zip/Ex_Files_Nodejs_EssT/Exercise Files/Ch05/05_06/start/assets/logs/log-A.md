LOG A
=====
