Ben Franklin
===============

* You may delay, but time will not.
* Tell me and I forget. Teach me and I remember. Involve me and I learn.
* It takes many good deeds to build a good reputation, and only one bad one to lose it.
* Early to bed and early to rise makes a man healthy, wealthy and wise.
* By failing to prepare, you are preparing to fail.
* An investment in knowledge pays the best interest.
* Well done is better than well said.

George Washington
=================

* It is far better to be alone, than to be in bad company.
* It is better to offer no excuse than a bad one.
* Few men have virtue to withstand the highest bidder.
* Happiness and moral duty are inseparably connected.
